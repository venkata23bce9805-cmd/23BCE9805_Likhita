package com.startuphub.service.impl;

import com.startuphub.dto.DashboardStatsResponse;
import com.startuphub.repository.FundingApplicationRepository;
import com.startuphub.repository.InvestorRepository;
import com.startuphub.repository.MentorRepository;
import com.startuphub.repository.ProgramRepository;
import com.startuphub.repository.StartupRepository;
import com.startuphub.service.DashboardService;
import org.springframework.stereotype.Service;

@Service
public class DashboardServiceImpl implements DashboardService {

    private final StartupRepository startupRepository;
    private final InvestorRepository investorRepository;
    private final MentorRepository mentorRepository;
    private final ProgramRepository programRepository;
    private final FundingApplicationRepository fundingApplicationRepository;

    public DashboardServiceImpl(
            StartupRepository startupRepository,
            InvestorRepository investorRepository,
            MentorRepository mentorRepository,
            ProgramRepository programRepository,
            FundingApplicationRepository fundingApplicationRepository
    ) {
        this.startupRepository = startupRepository;
        this.investorRepository = investorRepository;
        this.mentorRepository = mentorRepository;
        this.programRepository = programRepository;
        this.fundingApplicationRepository = fundingApplicationRepository;
    }

    @Override
    public DashboardStatsResponse getStats() {
        return new DashboardStatsResponse(
                startupRepository.count(),
                investorRepository.count(),
                mentorRepository.count(),
                programRepository.count(),
                fundingApplicationRepository.count()
        );
    }
}
