package com.startuphub.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class ProgramResponse {

    private final String id;
    private final String name;
    private final String description;
    private final String duration;
    private final LocalDate startDate;
    private final LocalDateTime createdAt;

    public ProgramResponse(String id, String name, String description, String duration, LocalDate startDate, LocalDateTime createdAt) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.duration = duration;
        this.startDate = startDate;
        this.createdAt = createdAt;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getDuration() {
        return duration;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
