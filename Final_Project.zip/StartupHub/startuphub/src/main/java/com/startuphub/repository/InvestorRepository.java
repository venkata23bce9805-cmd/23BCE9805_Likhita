package com.startuphub.repository;

import com.startuphub.model.Investor;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface InvestorRepository extends MongoRepository<Investor, String> {
}
