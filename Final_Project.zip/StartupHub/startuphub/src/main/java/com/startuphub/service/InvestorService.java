package com.startuphub.service;

import com.startuphub.dto.InvestorRequest;
import com.startuphub.dto.InvestorResponse;
import java.util.List;

public interface InvestorService {

    InvestorResponse createInvestor(InvestorRequest request);

    List<InvestorResponse> getAllInvestors();

    InvestorResponse getInvestorById(String id);

    InvestorResponse updateInvestor(String id, InvestorRequest request);

    void deleteInvestor(String id);
}
