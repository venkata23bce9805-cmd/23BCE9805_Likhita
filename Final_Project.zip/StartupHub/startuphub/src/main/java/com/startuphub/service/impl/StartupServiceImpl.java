package com.startuphub.service.impl;

import com.startuphub.dto.CreateStartupRequest;
import com.startuphub.dto.StartupResponse;
import com.startuphub.dto.UpdateStartupRequest;
import com.startuphub.exception.BadRequestException;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.model.Startup;
import com.startuphub.repository.InvestorRepository;
import com.startuphub.repository.MentorRepository;
import com.startuphub.repository.ProgramRepository;
import com.startuphub.repository.StartupRepository;
import com.startuphub.service.StartupService;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class StartupServiceImpl implements StartupService {

    private final StartupRepository startupRepository;
    private final MentorRepository mentorRepository;
    private final InvestorRepository investorRepository;
    private final ProgramRepository programRepository;

    public StartupServiceImpl(
            StartupRepository startupRepository,
            MentorRepository mentorRepository,
            InvestorRepository investorRepository,
            ProgramRepository programRepository
    ) {
        this.startupRepository = startupRepository;
        this.mentorRepository = mentorRepository;
        this.investorRepository = investorRepository;
        this.programRepository = programRepository;
    }

    @Override
    public StartupResponse createStartup(CreateStartupRequest request) {
        validateRequiredFields(request.getName(), request.getFounder(), request.getDomain(), request.getStage());

        Startup startup = new Startup();
        startup.setName(clean(request.getName()));
        startup.setFounder(clean(request.getFounder()));
        startup.setDomain(clean(request.getDomain()));
        startup.setStage(clean(request.getStage()));
        startup.setDescription(cleanNullable(request.getDescription()));
        startup.setCreatedAt(Instant.now());

        return toResponse(startupRepository.save(startup));
    }

    @Override
    public List<StartupResponse> getAllStartups() {
        return startupRepository.findAll()
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    public StartupResponse getStartupById(String id) {
        return toResponse(findStartupById(id));
    }

    @Override
    public StartupResponse updateStartup(String id, UpdateStartupRequest request) {
        validateRequiredFields(request.getName(), request.getFounder(), request.getDomain(), request.getStage());

        Startup startup = findStartupById(id);
        startup.setName(clean(request.getName()));
        startup.setFounder(clean(request.getFounder()));
        startup.setDomain(clean(request.getDomain()));
        startup.setStage(clean(request.getStage()));
        startup.setDescription(cleanNullable(request.getDescription()));

        return toResponse(startupRepository.save(startup));
    }

    @Override
    public void deleteStartup(String id) {
        Startup startup = findStartupById(id);
        startupRepository.delete(startup);
    }

    @Override
    public StartupResponse assignMentorToStartup(String startupId, String mentorId) {
        String safeStartupId = requireId(startupId, "Startup id is required");
        String safeMentorId = requireId(mentorId, "Mentor id is required");

        Startup startup = findStartupById(safeStartupId);
        if (!mentorRepository.existsById(safeMentorId)) {
            throw new ResourceNotFoundException("Mentor not found with id: " + safeMentorId);
        }
        startup.setMentorIds(addIfAbsent(startup.getMentorIds(), safeMentorId));
        return toResponse(startupRepository.save(startup));
    }

    @Override
    public StartupResponse assignInvestorToStartup(String startupId, String investorId) {
        String safeStartupId = requireId(startupId, "Startup id is required");
        String safeInvestorId = requireId(investorId, "Investor id is required");

        Startup startup = findStartupById(safeStartupId);
        if (!investorRepository.existsById(safeInvestorId)) {
            throw new ResourceNotFoundException("Investor not found with id: " + safeInvestorId);
        }
        startup.setInvestorIds(addIfAbsent(startup.getInvestorIds(), safeInvestorId));
        return toResponse(startupRepository.save(startup));
    }

    @Override
    public StartupResponse assignProgramToStartup(String startupId, String programId) {
        String safeStartupId = requireId(startupId, "Startup id is required");
        String safeProgramId = requireId(programId, "Program id is required");

        Startup startup = findStartupById(safeStartupId);
        if (!programRepository.existsById(safeProgramId)) {
            throw new ResourceNotFoundException("Program not found with id: " + safeProgramId);
        }
        startup.setProgramIds(addIfAbsent(startup.getProgramIds(), safeProgramId));
        return toResponse(startupRepository.save(startup));
    }

    @Override
    public List<StartupResponse> searchStartupsByName(String name) {
        validateTextParameter(name, "Search name is required");
        return startupRepository.findByNameContainingIgnoreCase(name.trim())
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    public List<StartupResponse> filterStartupsByFounder(String founder) {
        validateTextParameter(founder, "Founder filter is required");
        return startupRepository.findByFounderIgnoreCase(founder.trim())
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    public List<StartupResponse> filterStartupsByDomain(String domain) {
        validateTextParameter(domain, "Domain filter is required");
        return startupRepository.findByDomainIgnoreCase(domain.trim())
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    public List<StartupResponse> filterStartupsByStage(String stage) {
        validateTextParameter(stage, "Stage filter is required");
        return startupRepository.findByStageIgnoreCase(stage.trim())
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Override
    public Page<StartupResponse> getStartupsPage(int page, int size, String sortBy, String direction) {
        if (page < 0 || size <= 0) {
            throw new BadRequestException("Page must be zero or greater and size must be greater than zero");
        }

        String safeSortBy = normalizeSortBy(sortBy);
        Sort.Direction safeDirection = "desc".equalsIgnoreCase(direction) ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(safeDirection, safeSortBy));

        return startupRepository.findAll(pageable).map(this::toResponse);
    }

    private Startup findStartupById(String id) {
        return startupRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Startup not found with id: " + id));
    }

    private String requireId(String id, String message) {
        if (isBlank(id)) {
            throw new BadRequestException(message);
        }
        return id.trim();
    }

    private void validateRequiredFields(String name, String founder, String domain, String stage) {
        if (isBlank(name) || isBlank(founder) || isBlank(domain) || isBlank(stage)) {
            throw new BadRequestException("Startup name, founder, domain, and stage are required");
        }
    }

    private void validateTextParameter(String value, String message) {
        if (isBlank(value)) {
            throw new BadRequestException(message);
        }
    }

    private List<String> addIfAbsent(List<String> ids, String id) {
        List<String> safeIds = sanitizeIds(ids);
        if (!safeIds.contains(id)) {
            safeIds.add(id);
        }
        return safeIds;
    }

    private List<String> sanitizeIds(List<String> ids) {
        if (ids == null) {
            return new ArrayList<>();
        }

        Set<String> uniqueIds = new LinkedHashSet<>();
        for (String id : ids) {
            if (!isBlank(id)) {
                uniqueIds.add(id.trim());
            }
        }
        return new ArrayList<>(uniqueIds);
    }

    private String normalizeSortBy(String sortBy) {
        if ("name".equalsIgnoreCase(sortBy)) {
            return "name";
        }
        if ("createdAt".equalsIgnoreCase(sortBy)) {
            return "createdAt";
        }
        throw new BadRequestException("Sorting is supported only by createdAt and name");
    }

    private boolean isBlank(String value) {
        return value == null || value.trim().isEmpty();
    }

    private String clean(String value) {
        return value.trim();
    }

    private String cleanNullable(String value) {
        return value == null ? null : value.trim();
    }

    private StartupResponse toResponse(Startup startup) {
        return new StartupResponse(
                startup.getId(),
                startup.getName(),
                startup.getFounder(),
                startup.getDomain(),
                startup.getStage(),
                startup.getDescription(),
                sanitizeIds(startup.getMentorIds()),
                sanitizeIds(startup.getInvestorIds()),
                sanitizeIds(startup.getProgramIds()),
                startup.getCreatedAt()
        );
    }
}
