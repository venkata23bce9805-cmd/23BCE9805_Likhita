package com.startuphub.dto;

import java.math.BigDecimal;
import java.time.Instant;

public class FundingApplicationResponse {

    private final String id;
    private final String startupId;
    private final String investorId;
    private final BigDecimal amount;
    private final String status;
    private final Instant createdAt;

    public FundingApplicationResponse(String id, String startupId, String investorId, BigDecimal amount, String status, Instant createdAt) {
        this.id = id;
        this.startupId = startupId;
        this.investorId = investorId;
        this.amount = amount;
        this.status = status;
        this.createdAt = createdAt;
    }

    public String getId() {
        return id;
    }

    public String getStartupId() {
        return startupId;
    }

    public String getInvestorId() {
        return investorId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public String getStatus() {
        return status;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
