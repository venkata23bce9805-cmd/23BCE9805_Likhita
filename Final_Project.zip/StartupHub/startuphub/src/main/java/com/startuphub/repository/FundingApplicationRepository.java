package com.startuphub.repository;

import com.startuphub.model.FundingApplication;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FundingApplicationRepository extends MongoRepository<FundingApplication, String> {
}
