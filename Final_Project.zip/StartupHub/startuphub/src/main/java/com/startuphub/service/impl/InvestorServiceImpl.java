package com.startuphub.service.impl;

import com.startuphub.dto.InvestorRequest;
import com.startuphub.dto.InvestorResponse;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.model.Investor;
import com.startuphub.repository.InvestorRepository;
import com.startuphub.service.InvestorService;
import java.time.Instant;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class InvestorServiceImpl implements InvestorService {

    private final InvestorRepository investorRepository;

    public InvestorServiceImpl(InvestorRepository investorRepository) {
        this.investorRepository = investorRepository;
    }

    @Override
    public InvestorResponse createInvestor(InvestorRequest request) {
        Investor investor = new Investor();
        applyRequest(investor, request);
        investor.setCreatedAt(Instant.now());
        return toResponse(investorRepository.save(investor));
    }

    @Override
    public List<InvestorResponse> getAllInvestors() {
        return investorRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    public InvestorResponse getInvestorById(String id) {
        return toResponse(findInvestorById(id));
    }

    @Override
    public InvestorResponse updateInvestor(String id, InvestorRequest request) {
        Investor investor = findInvestorById(id);
        applyRequest(investor, request);
        return toResponse(investorRepository.save(investor));
    }

    @Override
    public void deleteInvestor(String id) {
        investorRepository.delete(findInvestorById(id));
    }

    private Investor findInvestorById(String id) {
        return investorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Investor not found with id: " + id));
    }

    private void applyRequest(Investor investor, InvestorRequest request) {
        investor.setName(clean(request.getName()));
        investor.setEmail(clean(request.getEmail()));
        investor.setFirm(clean(request.getFirm()));
        investor.setInvestmentFocus(clean(request.getInvestmentFocus()));
    }

    private String clean(String value) {
        return value.trim();
    }

    private InvestorResponse toResponse(Investor investor) {
        return new InvestorResponse(
                investor.getId(),
                investor.getName(),
                investor.getEmail(),
                investor.getFirm(),
                investor.getInvestmentFocus(),
                investor.getCreatedAt()
        );
    }
}
