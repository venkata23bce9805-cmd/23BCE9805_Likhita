package com.startuphub.service;

import com.startuphub.dto.DashboardStatsResponse;

public interface DashboardService {

    DashboardStatsResponse getStats();
}
