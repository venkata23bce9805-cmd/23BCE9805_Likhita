package com.startuphub.service;

import com.startuphub.dto.CreateStartupRequest;
import com.startuphub.dto.StartupResponse;
import com.startuphub.dto.UpdateStartupRequest;
import java.util.List;
import org.springframework.data.domain.Page;

public interface StartupService {

    StartupResponse createStartup(CreateStartupRequest request);

    List<StartupResponse> getAllStartups();

    StartupResponse getStartupById(String id);

    StartupResponse updateStartup(String id, UpdateStartupRequest request);

    void deleteStartup(String id);

    StartupResponse assignMentorToStartup(String startupId, String mentorId);

    StartupResponse assignInvestorToStartup(String startupId, String investorId);

    StartupResponse assignProgramToStartup(String startupId, String programId);

    List<StartupResponse> searchStartupsByName(String name);

    List<StartupResponse> filterStartupsByFounder(String founder);

    List<StartupResponse> filterStartupsByDomain(String domain);

    List<StartupResponse> filterStartupsByStage(String stage);

    Page<StartupResponse> getStartupsPage(int page, int size, String sortBy, String direction);
}
