package com.startuphub.dto;

import java.time.Instant;

public class MentorResponse {

    private final String id;
    private final String name;
    private final String email;
    private final String expertise;
    private final Integer experienceYears;
    private final Instant createdAt;

    public MentorResponse(String id, String name, String email, String expertise, Integer experienceYears, Instant createdAt) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.expertise = expertise;
        this.experienceYears = experienceYears;
        this.createdAt = createdAt;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getExpertise() {
        return expertise;
    }

    public Integer getExperienceYears() {
        return experienceYears;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
