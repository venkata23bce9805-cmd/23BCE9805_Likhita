package com.startuphub.dto;

import java.time.Instant;

public class InvestorResponse {

    private final String id;
    private final String name;
    private final String email;
    private final String firm;
    private final String investmentFocus;
    private final Instant createdAt;

    public InvestorResponse(String id, String name, String email, String firm, String investmentFocus, Instant createdAt) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.firm = firm;
        this.investmentFocus = investmentFocus;
        this.createdAt = createdAt;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getFirm() {
        return firm;
    }

    public String getInvestmentFocus() {
        return investmentFocus;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
