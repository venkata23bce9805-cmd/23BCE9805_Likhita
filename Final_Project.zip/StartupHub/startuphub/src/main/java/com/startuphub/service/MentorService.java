package com.startuphub.service;

import com.startuphub.dto.MentorRequest;
import com.startuphub.dto.MentorResponse;
import java.util.List;

public interface MentorService {

    MentorResponse createMentor(MentorRequest request);

    List<MentorResponse> getAllMentors();

    MentorResponse getMentorById(String id);

    MentorResponse updateMentor(String id, MentorRequest request);

    void deleteMentor(String id);
}
