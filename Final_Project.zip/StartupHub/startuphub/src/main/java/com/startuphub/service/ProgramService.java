package com.startuphub.service;

import com.startuphub.dto.ProgramRequest;
import com.startuphub.dto.ProgramResponse;
import java.util.List;

public interface ProgramService {

    ProgramResponse createProgram(ProgramRequest request);

    List<ProgramResponse> getAllPrograms();

    ProgramResponse getProgramById(String id);

    ProgramResponse updateProgram(String id, ProgramRequest request);

    void deleteProgram(String id);
}
