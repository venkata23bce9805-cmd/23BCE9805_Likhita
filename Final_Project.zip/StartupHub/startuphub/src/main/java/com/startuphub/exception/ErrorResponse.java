package com.startuphub.exception;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import java.time.Instant;

@JsonPropertyOrder({"timestamp", "status", "message", "details"})
public class ErrorResponse {

    private final Instant timestamp;
    private final int status;
    private final String message;
    private final String details;

    public ErrorResponse(Instant timestamp, int status, String message, String details) {
        this.timestamp = timestamp;
        this.status = status;
        this.message = message;
        this.details = details;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    public int getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

    public String getDetails() {
        return details;
    }
}
