package com.startuphub.service.impl;

import com.startuphub.dto.FundingApplicationRequest;
import com.startuphub.dto.FundingApplicationResponse;
import com.startuphub.exception.BadRequestException;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.model.FundingApplication;
import com.startuphub.repository.FundingApplicationRepository;
import com.startuphub.repository.InvestorRepository;
import com.startuphub.repository.StartupRepository;
import com.startuphub.service.FundingApplicationService;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class FundingApplicationServiceImpl implements FundingApplicationService {

    private final FundingApplicationRepository fundingApplicationRepository;
    private final StartupRepository startupRepository;
    private final InvestorRepository investorRepository;

    public FundingApplicationServiceImpl(
            FundingApplicationRepository fundingApplicationRepository,
            StartupRepository startupRepository,
            InvestorRepository investorRepository
    ) {
        this.fundingApplicationRepository = fundingApplicationRepository;
        this.startupRepository = startupRepository;
        this.investorRepository = investorRepository;
    }

    @Override
    public FundingApplicationResponse createFundingApplication(FundingApplicationRequest request) {
        validateReferences(request);

        FundingApplication fundingApplication = new FundingApplication();
        applyRequest(fundingApplication, request);
        fundingApplication.setCreatedAt(Instant.now());

        return toResponse(fundingApplicationRepository.save(fundingApplication));
    }

    @Override
    public List<FundingApplicationResponse> getAllFundingApplications() {
        return fundingApplicationRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    public FundingApplicationResponse getFundingApplicationById(String id) {
        return toResponse(findFundingApplicationById(id));
    }

    @Override
    public FundingApplicationResponse updateFundingApplication(String id, FundingApplicationRequest request) {
        FundingApplication fundingApplication = findFundingApplicationById(id);
        validateReferences(request);
        applyRequest(fundingApplication, request);

        return toResponse(fundingApplicationRepository.save(fundingApplication));
    }

    @Override
    public void deleteFundingApplication(String id) {
        fundingApplicationRepository.delete(findFundingApplicationById(id));
    }

    private FundingApplication findFundingApplicationById(String id) {
        return fundingApplicationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Funding application not found with id: " + id));
    }

    private void validateReferences(FundingApplicationRequest request) {
        String startupId = requireText(request.getStartupId(), "Startup id is required");
        String investorId = requireText(request.getInvestorId(), "Investor id is required");

        if (!startupRepository.existsById(startupId)) {
            throw new ResourceNotFoundException("Startup not found with id: " + startupId);
        }
        if (!investorRepository.existsById(investorId)) {
            throw new ResourceNotFoundException("Investor not found with id: " + investorId);
        }
    }

    private void applyRequest(FundingApplication fundingApplication, FundingApplicationRequest request) {
        fundingApplication.setStartupId(requireText(request.getStartupId(), "Startup id is required"));
        fundingApplication.setInvestorId(requireText(request.getInvestorId(), "Investor id is required"));
        fundingApplication.setAmount(requirePositiveAmount(request.getAmount()));
        fundingApplication.setStatus(requireText(request.getStatus(), "Application status is required"));
    }

    private String requireText(String value, String message) {
        if (value == null || value.trim().isEmpty()) {
            throw new BadRequestException(message);
        }
        return value.trim();
    }

    private BigDecimal requirePositiveAmount(BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new BadRequestException("Funding amount must be positive");
        }
        return amount;
    }

    private FundingApplicationResponse toResponse(FundingApplication fundingApplication) {
        return new FundingApplicationResponse(
                fundingApplication.getId(),
                fundingApplication.getStartupId(),
                fundingApplication.getInvestorId(),
                fundingApplication.getAmount(),
                fundingApplication.getStatus(),
                fundingApplication.getCreatedAt()
        );
    }
}
