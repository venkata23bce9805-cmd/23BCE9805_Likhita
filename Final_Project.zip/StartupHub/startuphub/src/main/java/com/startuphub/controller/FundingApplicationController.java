package com.startuphub.controller;

import com.startuphub.dto.FundingApplicationRequest;
import com.startuphub.dto.FundingApplicationResponse;
import com.startuphub.service.FundingApplicationService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/funding-applications")
public class FundingApplicationController {

    private final FundingApplicationService fundingApplicationService;

    public FundingApplicationController(FundingApplicationService fundingApplicationService) {
        this.fundingApplicationService = fundingApplicationService;
    }

    @PostMapping
    public ResponseEntity<FundingApplicationResponse> createFundingApplication(
            @Valid @RequestBody FundingApplicationRequest request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(fundingApplicationService.createFundingApplication(request));
    }

    @GetMapping
    public ResponseEntity<List<FundingApplicationResponse>> getAllFundingApplications() {
        return ResponseEntity.ok(fundingApplicationService.getAllFundingApplications());
    }

    @GetMapping("/{id}")
    public ResponseEntity<FundingApplicationResponse> getFundingApplicationById(@PathVariable String id) {
        return ResponseEntity.ok(fundingApplicationService.getFundingApplicationById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<FundingApplicationResponse> updateFundingApplication(
            @PathVariable String id,
            @Valid @RequestBody FundingApplicationRequest request
    ) {
        return ResponseEntity.ok(fundingApplicationService.updateFundingApplication(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFundingApplication(@PathVariable String id) {
        fundingApplicationService.deleteFundingApplication(id);
        return ResponseEntity.noContent().build();
    }
}
