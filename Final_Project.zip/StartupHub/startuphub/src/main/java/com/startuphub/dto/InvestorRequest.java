package com.startuphub.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public class InvestorRequest {

    @NotBlank(message = "Investor name is required")
    private String name;

    @Email(message = "Investor email must be valid")
    @NotBlank(message = "Investor email is required")
    private String email;

    @NotBlank(message = "Firm is required")
    private String firm;

    @NotBlank(message = "Investment focus is required")
    private String investmentFocus;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirm() {
        return firm;
    }

    public void setFirm(String firm) {
        this.firm = firm;
    }

    public String getInvestmentFocus() {
        return investmentFocus;
    }

    public void setInvestmentFocus(String investmentFocus) {
        this.investmentFocus = investmentFocus;
    }
}
