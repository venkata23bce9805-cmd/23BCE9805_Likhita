package com.startuphub.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.context.annotation.Configuration;

@Configuration
@OpenAPIDefinition(info = @Info(title = "StartupHub API", version = "1.0", description = "StartupHub Backend APIs"))
public class OpenApiConfig {
}