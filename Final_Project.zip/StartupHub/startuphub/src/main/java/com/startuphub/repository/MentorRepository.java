package com.startuphub.repository;

import com.startuphub.model.Mentor;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface MentorRepository extends MongoRepository<Mentor, String> {
}
