package com.startuphub.dto;

import jakarta.validation.constraints.NotBlank;

public class UpdateStartupRequest {

    @NotBlank(message = "Startup name is required")
    private String name;

    @NotBlank(message = "Founder is required")
    private String founder;

    @NotBlank(message = "Domain is required")
    private String domain;

    @NotBlank(message = "Stage is required")
    private String stage;

    private String description;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFounder() {
        return founder;
    }

    public void setFounder(String founder) {
        this.founder = founder;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
