package com.startuphub.controller;

import com.startuphub.dto.InvestorRequest;
import com.startuphub.dto.InvestorResponse;
import com.startuphub.service.InvestorService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/investors")
public class InvestorController {

    private final InvestorService investorService;

    public InvestorController(InvestorService investorService) {
        this.investorService = investorService;
    }

    @PostMapping
    public ResponseEntity<InvestorResponse> createInvestor(@Valid @RequestBody InvestorRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(investorService.createInvestor(request));
    }

    @GetMapping
    public ResponseEntity<List<InvestorResponse>> getAllInvestors() {
        return ResponseEntity.ok(investorService.getAllInvestors());
    }

    @GetMapping("/{id}")
    public ResponseEntity<InvestorResponse> getInvestorById(@PathVariable String id) {
        return ResponseEntity.ok(investorService.getInvestorById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<InvestorResponse> updateInvestor(
            @PathVariable String id,
            @Valid @RequestBody InvestorRequest request
    ) {
        return ResponseEntity.ok(investorService.updateInvestor(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInvestor(@PathVariable String id) {
        investorService.deleteInvestor(id);
        return ResponseEntity.noContent().build();
    }
}
