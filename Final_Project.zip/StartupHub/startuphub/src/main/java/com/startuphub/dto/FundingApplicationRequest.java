package com.startuphub.dto;

import java.math.BigDecimal;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class FundingApplicationRequest {

    @NotBlank(message = "Startup id is required")
    private String startupId;

    @NotBlank(message = "Investor id is required")
    private String investorId;

    @NotNull(message = "Funding amount is required")
    @Positive(message = "Funding amount must be positive")
    private BigDecimal amount;

    @NotBlank(message = "Application status is required")
    private String status;

    public String getStartupId() {
        return startupId;
    }

    public void setStartupId(String startupId) {
        this.startupId = startupId;
    }

    public String getInvestorId() {
        return investorId;
    }

    public void setInvestorId(String investorId) {
        this.investorId = investorId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
