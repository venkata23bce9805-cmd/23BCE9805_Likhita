package com.startuphub.service.impl;

import com.startuphub.dto.ProgramRequest;
import com.startuphub.dto.ProgramResponse;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.model.Program;
import com.startuphub.repository.ProgramRepository;
import com.startuphub.service.ProgramService;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class ProgramServiceImpl implements ProgramService {

    private final ProgramRepository programRepository;

    public ProgramServiceImpl(ProgramRepository programRepository) {
        this.programRepository = programRepository;
    }

    @Override
    public ProgramResponse createProgram(ProgramRequest request) {
        Program program = new Program();
        applyRequest(program, request);
        program.setCreatedAt(LocalDateTime.now());
        return toResponse(programRepository.save(program));
    }

    @Override
    public List<ProgramResponse> getAllPrograms() {
        return programRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    public ProgramResponse getProgramById(String id) {
        return toResponse(findProgramById(id));
    }

    @Override
    public ProgramResponse updateProgram(String id, ProgramRequest request) {
        Program program = findProgramById(id);
        applyRequest(program, request);
        return toResponse(programRepository.save(program));
    }

    @Override
    public void deleteProgram(String id) {
        programRepository.delete(findProgramById(id));
    }

    private Program findProgramById(String id) {
        return programRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Program not found with id: " + id));
    }

    private void applyRequest(Program program, ProgramRequest request) {
        program.setName(clean(request.getName()));
        program.setDescription(cleanNullable(request.getDescription()));
        program.setDuration(clean(request.getDuration()));
        program.setStartDate(request.getStartDate());
    }

    private String clean(String value) {
        return value.trim();
    }

    private String cleanNullable(String value) {
        return value == null ? null : value.trim();
    }

    private ProgramResponse toResponse(Program program) {
        return new ProgramResponse(
                program.getId(),
                program.getName(),
                program.getDescription(),
                program.getDuration(),
                program.getStartDate(),
                program.getCreatedAt()
        );
    }
}
