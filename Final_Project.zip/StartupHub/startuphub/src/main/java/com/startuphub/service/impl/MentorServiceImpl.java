package com.startuphub.service.impl;

import com.startuphub.dto.MentorRequest;
import com.startuphub.dto.MentorResponse;
import com.startuphub.exception.ResourceNotFoundException;
import com.startuphub.model.Mentor;
import com.startuphub.repository.MentorRepository;
import com.startuphub.service.MentorService;
import java.time.Instant;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class MentorServiceImpl implements MentorService {

    private final MentorRepository mentorRepository;

    public MentorServiceImpl(MentorRepository mentorRepository) {
        this.mentorRepository = mentorRepository;
    }

    @Override
    public MentorResponse createMentor(MentorRequest request) {
        Mentor mentor = new Mentor();
        applyRequest(mentor, request);
        mentor.setCreatedAt(Instant.now());
        return toResponse(mentorRepository.save(mentor));
    }

    @Override
    public List<MentorResponse> getAllMentors() {
        return mentorRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    public MentorResponse getMentorById(String id) {
        return toResponse(findMentorById(id));
    }

    @Override
    public MentorResponse updateMentor(String id, MentorRequest request) {
        Mentor mentor = findMentorById(id);
        applyRequest(mentor, request);
        return toResponse(mentorRepository.save(mentor));
    }

    @Override
    public void deleteMentor(String id) {
        mentorRepository.delete(findMentorById(id));
    }

    private Mentor findMentorById(String id) {
        return mentorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Mentor not found with id: " + id));
    }

    private void applyRequest(Mentor mentor, MentorRequest request) {
        mentor.setName(clean(request.getName()));
        mentor.setEmail(clean(request.getEmail()));
        mentor.setExpertise(clean(request.getExpertise()));
        mentor.setExperienceYears(request.getExperienceYears());
    }

    private String clean(String value) {
        return value.trim();
    }

    private MentorResponse toResponse(Mentor mentor) {
        return new MentorResponse(
                mentor.getId(),
                mentor.getName(),
                mentor.getEmail(),
                mentor.getExpertise(),
                mentor.getExperienceYears(),
                mentor.getCreatedAt()
        );
    }
}
