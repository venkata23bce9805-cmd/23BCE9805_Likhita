package com.startuphub.controller;

import com.startuphub.dto.CreateStartupRequest;
import com.startuphub.dto.StartupResponse;
import com.startuphub.dto.UpdateStartupRequest;
import com.startuphub.service.StartupService;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/startups")
public class StartupController {

    private final StartupService startupService;

    public StartupController(StartupService startupService) {
        this.startupService = startupService;
    }

    @PostMapping
    public ResponseEntity<StartupResponse> createStartup(@Valid @RequestBody CreateStartupRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(startupService.createStartup(request));
    }

    @GetMapping
    public ResponseEntity<?> getAllStartups(
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        if (page == null && size == null) {
            return ResponseEntity.ok(startupService.getAllStartups());
        }

        int safePage = page == null ? 0 : page;
        int safeSize = size == null ? 10 : size;
        return ResponseEntity.ok(startupService.getStartupsPage(safePage, safeSize,
                sortBy, direction));
    }

    @GetMapping("/{id}")
    public ResponseEntity<StartupResponse> getStartupById(@PathVariable String id) {
        return ResponseEntity.ok(startupService.getStartupById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<StartupResponse> updateStartup(
            @PathVariable String id,
            @Valid @RequestBody UpdateStartupRequest request) {
        return ResponseEntity.ok(startupService.updateStartup(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteStartup(@PathVariable String id) {
        startupService.deleteStartup(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{startupId}/mentors/{mentorId}")
    public ResponseEntity<StartupResponse> assignMentor(
            @PathVariable String startupId,
            @PathVariable String mentorId) {
        return ResponseEntity.ok(startupService.assignMentorToStartup(startupId, mentorId));
    }

    @PostMapping("/{startupId}/investors/{investorId}")
    public ResponseEntity<StartupResponse> assignInvestor(
            @PathVariable String startupId,
            @PathVariable String investorId) {
        return ResponseEntity.ok(startupService.assignInvestorToStartup(startupId, investorId));
    }

    @PostMapping("/{startupId}/programs/{programId}")
    public ResponseEntity<StartupResponse> assignProgram(
            @PathVariable String startupId,
            @PathVariable String programId) {
        return ResponseEntity.ok(startupService.assignProgramToStartup(startupId, programId));
    }

    @GetMapping("/search")
    public ResponseEntity<List<StartupResponse>> searchStartupsByName(@RequestParam String name) {
        return ResponseEntity.ok(startupService.searchStartupsByName(name));
    }

    @GetMapping("/filter/founder")
    public ResponseEntity<List<StartupResponse>> filterStartupsByFounder(@RequestParam String founder) {
        return ResponseEntity.ok(startupService.filterStartupsByFounder(founder));
    }

    @GetMapping("/filter/domain")
    public ResponseEntity<List<StartupResponse>> filterStartupsByDomain(@RequestParam String domain) {
        return ResponseEntity.ok(startupService.filterStartupsByDomain(domain));
    }

    @GetMapping("/filter/stage")
    public ResponseEntity<List<StartupResponse>> filterStartupsByStage(@RequestParam String stage) {
        return ResponseEntity.ok(startupService.filterStartupsByStage(stage));
    }

    @GetMapping("/page")
    public ResponseEntity<Page<StartupResponse>> getStartupsPage(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "createdAt") String sortBy,
            @RequestParam(defaultValue = "desc") String direction) {
        return ResponseEntity.ok(startupService.getStartupsPage(page, size, sortBy,
                direction));
    }
}
