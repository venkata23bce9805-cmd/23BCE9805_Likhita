package com.startuphub.dto;

import java.time.Instant;
import java.util.List;

public class StartupResponse {

    private String id;
    private String name;
    private String founder;
    private String domain;
    private String stage;
    private String description;
    private List<String> mentorIds;
    private List<String> investorIds;
    private List<String> programIds;
    private Instant createdAt;

    public StartupResponse(String id, String name, String founder, String domain, String stage, String description,
            List<String> mentorIds, List<String> investorIds, List<String> programIds, Instant createdAt) {
        this.id = id;
        this.name = name;
        this.founder = founder;
        this.domain = domain;
        this.stage = stage;
        this.description = description;
        this.mentorIds = mentorIds;
        this.investorIds = investorIds;
        this.programIds = programIds;
        this.createdAt = createdAt;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getFounder() {
        return founder;
    }

    public String getDomain() {
        return domain;
    }

    public String getStage() {
        return stage;
    }

    public String getDescription() {
        return description;
    }

    public List<String> getMentorIds() {
        return mentorIds;
    }

    public List<String> getInvestorIds() {
        return investorIds;
    }

    public List<String> getProgramIds() {
        return programIds;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
