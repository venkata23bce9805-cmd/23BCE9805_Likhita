package com.startuphub.repository;

import com.startuphub.model.Startup;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface StartupRepository extends MongoRepository<Startup, String> {

    List<Startup> findByNameContainingIgnoreCase(String name);

    List<Startup> findByFounderIgnoreCase(String founder);

    List<Startup> findByDomainIgnoreCase(String domain);

    List<Startup> findByStageIgnoreCase(String stage);
}
