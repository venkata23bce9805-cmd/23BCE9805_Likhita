package com.startuphub.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class MentorRequest {

    @NotBlank(message = "Mentor name is required")
    private String name;

    @Email(message = "Mentor email must be valid")
    @NotBlank(message = "Mentor email is required")
    private String email;

    @NotBlank(message = "Expertise is required")
    private String expertise;

    @NotNull(message = "Experience years is required")
    @Positive(message = "Experience years must be positive")
    private Integer experienceYears;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getExpertise() {
        return expertise;
    }

    public void setExpertise(String expertise) {
        this.expertise = expertise;
    }

    public Integer getExperienceYears() {
        return experienceYears;
    }

    public void setExperienceYears(Integer experienceYears) {
        this.experienceYears = experienceYears;
    }
}
