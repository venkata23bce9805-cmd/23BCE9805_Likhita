package com.startuphub.dto;

public class DashboardStatsResponse {

    private final long totalStartups;
    private final long totalInvestors;
    private final long totalMentors;
    private final long totalPrograms;
    private final long totalFundingApplications;

    public DashboardStatsResponse(long totalStartups, long totalInvestors, long totalMentors, long totalPrograms, long totalFundingApplications) {
        this.totalStartups = totalStartups;
        this.totalInvestors = totalInvestors;
        this.totalMentors = totalMentors;
        this.totalPrograms = totalPrograms;
        this.totalFundingApplications = totalFundingApplications;
    }

    public long getTotalStartups() {
        return totalStartups;
    }

    public long getTotalInvestors() {
        return totalInvestors;
    }

    public long getTotalMentors() {
        return totalMentors;
    }

    public long getTotalPrograms() {
        return totalPrograms;
    }

    public long getTotalFundingApplications() {
        return totalFundingApplications;
    }
}
