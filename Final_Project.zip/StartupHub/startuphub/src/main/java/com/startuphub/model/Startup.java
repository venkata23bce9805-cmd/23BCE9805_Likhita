package com.startuphub.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "startups")
public class Startup {

    @Id
    private String id;
    private String name;
    private String founder;
    private String domain;
    private String stage;
    private String description;
    private List<String> mentorIds = new ArrayList<>();
    private List<String> investorIds = new ArrayList<>();
    private List<String> programIds = new ArrayList<>();
    private Instant createdAt;

    public Startup() {
    }

    public Startup(String id, String name, String founder, String domain, String stage, String description, List<String> mentorIds, List<String> investorIds, List<String> programIds, Instant createdAt) {
        this.id = id;
        this.name = name;
        this.founder = founder;
        this.domain = domain;
        this.stage = stage;
        this.description = description;
        setMentorIds(mentorIds);
        setInvestorIds(investorIds);
        setProgramIds(programIds);
        this.createdAt = createdAt;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFounder() {
        return founder;
    }

    public void setFounder(String founder) {
        this.founder = founder;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getMentorIds() {
        return mentorIds;
    }

    public void setMentorIds(List<String> mentorIds) {
        this.mentorIds = mentorIds == null ? new ArrayList<>() : mentorIds;
    }

    public List<String> getInvestorIds() {
        return investorIds;
    }

    public void setInvestorIds(List<String> investorIds) {
        this.investorIds = investorIds == null ? new ArrayList<>() : investorIds;
    }

    public List<String> getProgramIds() {
        return programIds;
    }

    public void setProgramIds(List<String> programIds) {
        this.programIds = programIds == null ? new ArrayList<>() : programIds;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
