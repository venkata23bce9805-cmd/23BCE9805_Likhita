package com.startuphub.service;

import com.startuphub.dto.FundingApplicationRequest;
import com.startuphub.dto.FundingApplicationResponse;
import java.util.List;

public interface FundingApplicationService {

    FundingApplicationResponse createFundingApplication(FundingApplicationRequest request);

    List<FundingApplicationResponse> getAllFundingApplications();

    FundingApplicationResponse getFundingApplicationById(String id);

    FundingApplicationResponse updateFundingApplication(String id, FundingApplicationRequest request);

    void deleteFundingApplication(String id);
}
